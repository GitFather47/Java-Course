package Classes;
public abstract class FinalRegistration implements StoreCourses,PreRegistration{
	public void Show(){
		System.out.println("Hello From Final Registration");
	}
	public abstract void confirmation();
		
	
}