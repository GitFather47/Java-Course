package interfaces;

import java.lang.*;


public interface ITransactions
{
	boolean withdraw(double amount);
	boolean deposit(double amount);
}