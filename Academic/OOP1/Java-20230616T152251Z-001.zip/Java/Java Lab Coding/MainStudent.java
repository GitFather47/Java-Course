public class MainStudent{
	public static void main(String[] args){
		Student st = new Student();
		st.setId(21);
		st.setName("Asadulla");
		st.setCgpa(3.50);
		st.showDetails();
	}
}