public class StartOfStoryBook{
	public static void main(String[] args){
		StoryBook sb1 = new StoryBook("1111-111","The Art of Thinking Clearly","Rolf Dobelli",350.00,2,"International Best Seller");
		sb1.setDiscountedRate(15.00);
		sb1.addQuantity(3);
		sb1.sellQuantity(2);
		sb1.showDetails();
		StoryBook sb2 = new StoryBook("2222-2222","Start With Why","Simon Sneak",300.00,1,"International Best Seller");
		sb2.setDiscountedRate(10.00);
		sb2.addQuantity(2);
		sb2.sellQuantity(1);
		sb2.showDetails();
		//Text Boook
		TextBook t1 = new TextBook("3333-3333","Physic 2","Resnick & Halliday ",500,5,2);
		t1.setDiscountedRate(5.00);
		t1.addQuantity(5);
		t1.sellQuantity(2);
		t1.showDetails();
		TextBook t2 = new TextBook("4444-4444","Beginning C","Ivor Horton",400,1,12);
		t2.setDiscountedRate(7.00);
		t2.addQuantity(2);
		t2.sellQuantity(1);
		t2.showDetails();
	}
}