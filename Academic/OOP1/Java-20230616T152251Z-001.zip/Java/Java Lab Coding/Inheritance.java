public class Inheritance{
	 class vehicle {
		public String brandName = "Mustang";
		public void Horn(){
			System.out.println("Pee pee poo poo.....");
		}
	}
	class Car extends vehicle{
		public void speeding(){
			System.out.println("Speeding Up.....!");
		}
		public void braking(){
			System.out.println("Applying Brake.....");
		}
	}
	
}
	

