public class Start1{
	public static void main(String[] args){
		Book1 b1 = new Book1("21-45862-3","A book 1","Abcd",230,2);
		b1.addQuantity(2);
		b1.sellQuantity(3);
		b1.showDetails();
		Book1 b2 = new Book1("21-458622-3","A book 2","Abcdefg",500,4);
		b2.addQuantity(5);
		b2.sellQuantity(3);
		b2.showDetails();
	}
}