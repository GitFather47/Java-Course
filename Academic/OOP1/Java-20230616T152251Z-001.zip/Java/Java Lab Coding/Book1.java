public class Book1{
	private String isbn;
	private String bookTitle;
	private String authorName;
	private double price;
	private int availableQuantity;
	public int newAvailableQuantity; 
	public int newlyAddedQuantity;
	public int sellQuantity;
	public Book1(){
		
	}
	public Book1(String isbn,String bookTitle,String authorName,double price,int availableQuantity){
		this.isbn =isbn;
		this.bookTitle=bookTitle;
		this.authorName=authorName;
		this.price =price;
		this.availableQuantity = availableQuantity;
	}
	
	//set get for isbn
	public void setIsbn(String isbn){
		this.isbn = isbn;
	}
	public String getIsbn(){
		return isbn; 
	}
	//set get for bookTitle
	public void setBookTitle(String bookTitle){
		this.bookTitle =bookTitle;
	}
	public String getBookTitle(){
		return bookTitle;
	}
	//set get for authorName
	public void setAuthorName(String authorName){
		this.authorName =authorName;
	}
	public String getAuthorName(){
		return authorName;
	}
	//set get for price 
	public void setPrice(double price){
		this.price =price;
	}
	public double getPrice(){
		return price;
	}
	//set get for availableQuantity
	public void setAvailableQuantity(int availableQuantity){
		this.availableQuantity = availableQuantity;
	}
	public int getAvailableQuantity(){
		return availableQuantity;
	}
	public void addQuantity(int amount){
		if(amount > 0){
			newAvailableQuantity = availableQuantity + amount;
			newlyAddedQuantity = amount;	
		}
		
		else{
			newAvailableQuantity = availableQuantity;
			
		}
		
	}
	public void sellQuantity(int amount){
		
		if(newAvailableQuantity>amount){
			newAvailableQuantity = newAvailableQuantity - amount;
			sellQuantity = amount;			
		}
		else{
			newAvailableQuantity = newAvailableQuantity;
			sellQuantity = 0;			
		}
		
	}
	public void showDetails(){
		System.out.println("International Standard Book Number :"+ isbn);
		System.out.println("Book Name :"+ bookTitle);
		System.out.println("Book Author Name :" + authorName);
		System.out.println("Available Book In Store :" + availableQuantity);
		System.out.println("Book Price :"+ price);
		System.out.println("Newly Added Quantity of Book: "+ newlyAddedQuantity);
		System.out.println("Selling Quantity of Book: "+ sellQuantity);
		System.out.println("After Selling Number of Book Copy Available :"+ newAvailableQuantity);
		
		
		System.out.format("\n");
	}
}