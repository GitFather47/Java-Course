//Method Overriding
/*
1)Method overriding is used to provide the specific implementation of the method 
that is already provided by its super class(Base Class).
2) Method overriding occurs in two classes that have IS-A (inheritance) relationship.
3)In case of method overriding, parameter must be same.
4)Method overriding is the example of run time polymorphism.
5)Return type must be same or covariant(Ignore this term) in method overriding.
*/




public class MethodOveriding{
	public static void main (String[] args){
	A a =new A();
	a.meth1();	
	B b = new B();
	b.meth1();
	}
}
public class A{
	int a;
	public int number(int num){
		a =num;
		return a;
	}
	public void meth1(){
		System.out.println("I'm method 1 of Class A");
	}
}
public class B extends A{
	@Override
	public void meth1(){
		
		System.out.println("I'm method 1 of Class B");
	}
}