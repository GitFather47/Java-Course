public class TextBook{
	private String isbn;
	private String bookTitle;
	private String authorName;
	private double price;
	private int availableQuantity;
	private int standard;
	private static double discountRate;
	public int newQuantity;
	public int totalAvailableQuantity;
	public int sellingAmount;
	public TextBook(){
		
	}
	public TextBook(String isbn,String bookTitle,String authorName,double price, int availableQuantity, int standard){
		this.isbn =isbn;
		this.bookTitle=bookTitle;
		this.authorName=authorName;
		this.price =price;
		this.availableQuantity = availableQuantity;
		this.standard = standard;
	}
	//set get for static discount 
	public static void setDiscountedRate(double rate){
		discountRate = rate;
	}
	public static double getDiscountRate(){
		return discountRate;
	}
	//set get for isbn
	public void setIsbn(String isbn){
		this.isbn = isbn;
	}
	public String getIsbn(){
		return isbn; 
	}
	//set get for bookTitle
	public void setBookTitle(String bookTitle){
		this.bookTitle =bookTitle;
	}
	public String getBookTitle(){
		return bookTitle;
	}
	//set get for authorName
	public void setAuthorName(String authorName){
		this.authorName =authorName;
	}
	public String getAuthorName(){
		return authorName;
	}
	//set get for price 
	public void setPrice(double price){
		this.price =price;
	}
	public double getPrice(){
		return price;
	}
	//set get method for availableQuantity
	public void setAvailableQuantity(int availableQuantity){
		this.availableQuantity = availableQuantity;
	}
	public int getAvailableQuantity(){
		return availableQuantity;
	}
	//set get for standard 
	public void setStandard(int standard){
		this.standard = standard;
	}
	public int getStandard(){
		return standard;
	}
	//methods for add quantity
	public void addQuantity(int amount){
		if(amount>0){
			newQuantity = availableQuantity + amount;
			totalAvailableQuantity = newQuantity;
		}
		else{
			newQuantity = availableQuantity;
		}
	}
	//methods for sell Quantity
	public void sellQuantity(int amount){
		if(amount<newQuantity){
			newQuantity = newQuantity-amount;
			sellingAmount = amount;
		}
		else{
			totalAvailableQuantity = newQuantity;
			sellingAmount = 0;
		}
	}
	//Show Details Method
	public void showDetails(){
		System.out.println("International Standard Book Number :"+ isbn);
		System.out.println("Book Name :"+ bookTitle);
		System.out.println("Book Author Name :" + authorName);
		System.out.println("The Standard Of Book Is:" + standard);
		System.out.println("Book Price :"+ price);
		System.out.println("Available Discount For Book:" + discountRate +"%");
		System.out.println("Available Book In Store :" + availableQuantity);
		System.out.println("Total Books Avaialbe After Newly Added: "+ totalAvailableQuantity);
		System.out.println("Total Number of sold  of Book: "+ sellingAmount);
		System.out.println("After Selling Number of Book  Available :"+ newQuantity);
		
		
		System.out.format("\n");
	}
}