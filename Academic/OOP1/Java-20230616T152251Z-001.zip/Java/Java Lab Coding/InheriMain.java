public class InheriMain{
	public static void main(String[] args){
		vehicle v1 = new vehicle();
		Car c1 = new Car();
		System.out.println("Name:" +c1.brandName);
		c1.speeding();
		c1.Horn();
		c1.braking();
		
	}
}