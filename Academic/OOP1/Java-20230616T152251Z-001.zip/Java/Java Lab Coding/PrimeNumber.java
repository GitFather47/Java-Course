public class PrimeNumber{
	public static void main(String[] args){
		int num = 15;
		boolean flag = true;
		for(int i =2;i<=num/2;i++){
			System.out.println(i);
			if (num%i ==0){

			flag = false;
			break;
			}
			else{
			flag = true;
			}
		}
	
		if(flag){
			System.out.println(num + " This is  a Prime Number");
		}
		else{
			System.out.println(num + " This is not a Prime Number");
		}
		
		
		
		
	}
}