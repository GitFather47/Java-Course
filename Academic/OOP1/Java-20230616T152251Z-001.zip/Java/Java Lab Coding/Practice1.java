import java.util.Scanner;
public class Practice1{
	public static void main(String[] args){
		int number =15;
		/*
		I'm going to try all of this basic thing
		Array,Loop
		*/
		//boolean condition = false;
		/*
		Scanner input = new Scanner(System.in);
		System.out.println("Enter a Number");
		//int x = input.nextInt();
		System.out.println("Enter a Number");
		float y = input.nextFloat();
		if(y==1.00){
			System.out.println("Condition is true");
		}//statement 1 end
		else{
			System.out.println("Condition is false");
		}
		*/
		//if,else
			/*
		
		System.out.print("Guess an integer number: ");
		int guess = input.nextInt();
		if(guess==number){
		System.out.println("Congratulations!" + "You WIn!");
		}
		else if (number > guess){
			System.out.println("DGM!" + "TFH");
		}
		else{
			System.out.println("Again DGM!!" + "Again TFH");
		}
		*/
		//0.00000000000001; epsilon 
		//threshold
		/*
		double a = 0.3;
		System.out.println("a =" + a);

		double b = 0.1 + 0.1 + 0.1;
		System.out.println(b);
		double epsilon = 0.00000000001 ;
		System.out.println (epsilon);
		if(Math.abs(a-b)<epsilon){
			System.out.println("Both are same.");
		}
		else {
			System.out.println("We are not same bro!");
		}
		*/
		/*
		Scanner input = new Scanner(System.in);
		System.out.println("Enter a number between 1 to 7: ");
		int day = input.nextInt();
		switch (day){
			case 1,2,3,4 -> System.out.println("Week Days");
			
			case 5,6,7 -> System.out.println("Weekends");
		*/	
			
			
		}
		
	}
}