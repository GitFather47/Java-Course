public class Vehicle
{
	
	private String vehicleName;
	private String vehicleModelNumber;
	private String vehicleCompanyName;
	private double vehiclePrice;
	private int availableVehicleQuantity;
	private static double discountRate;
	public int newQuantity;
	public int totalAvailableQuantity;
	public int sellingAmount;
	
	public Vehicle(){
		
	}
	public Vehicle(String vehicleName,String vehicleModelNumber,String vehicleCompanyName,double vehiclePrice,int availableQuantity);
	{
		this.vehicleName = vehicleName;
		this.vehicleModelNumber = vehicleModelNumber;
		this.vehicleModelNumber = vehicleModelNumber;
		this.vehiclePrice = vehiclePrice;
		this.availableQuantity=availableQuantity;
		
	}
	public void setName(String vehicleName)
	{
		this.vehicleName= vehicleName;
	}
	public String getName()
	{
		return name;
	}
	public void setModelNumber(String vehicleModelNumber)
	{
	    this.vehicleModelNumber=vehicleModelNumber;
	}
	public String getModelNumber()
	{
		return modelNumber;
	}
	public void setCompanyName(String companyName)
	{
	    this.companyName=companyName;
	}
	public String getCompanyName()
	{
		return companyName;
	}
	public void setPrice(double price)
	{
	    this.price=price;
	}
	public double getPrice()
	{
		return price;
	}
	public void setAvailableQuantity(int availableQuantity)
	{
		this.availableQuantity=availableQuantity;
	}
	public int getAvailableQuantity()
	{
		return availableQuantity;
	}
	public void setCategory(String category)
	{
		this.category=category;
	}
	public String getCategory()
	{
		return category;
	}
	public static void setDiscountrate(double rate )
	{
	   discountRate= rate;
	}
	public static double getDiscountrate()
	{
		return discountRate;
	}
	public void addQuantity(int amount)
	{
		newAvailableQuantity=availableQuantity + amount;
		newlyAddedQuantity=amount;
	}
	public void sellQuantity(int amount)
	{
		newAvailableQuantity= newAvailableQuantity - amount;
		sellQuantity=amount;
	}
	public void showdetails()
	{
		System.out.println("CAR Name: "+ name);
		System.out.println("Model Number: "+ modelNumber);
        System.out.println("Company Name: "+ companyName);
        System.out.println("Car Price : "+ price);
        System.out.println("Newly Added Quantity of Car: "+ newlyAddedQuantity);
		System.out.println("Car category: "+ category);
		System.out.println("Discount rate : "+discountRate);
        System.out.println("Sell Quantity of Car "+ sellQuantity);
        System.out.println("Car Available :"+ newAvailableQuantity);		
	}
	
}