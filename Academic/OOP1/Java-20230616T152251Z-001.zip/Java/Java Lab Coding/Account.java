public class Account{
	private int accountNumber;
	private String accountHolderName;
	private double balance;
	private static String organization;
	//Methods
	//set get method for account Number
	static{
		organization = "Aiub";
	}
	public void setAccountNumber(int an){
		accountNumber = an;
	}
	public int getAccountNumber(){
		return accountNumber;
	}
	//set get method for account Holder Name
	public void setAccountHolderName(String ahn){
		accountHolderName = ahn;
	}
	public String getAccountHolderName(){
		return accountHolderName;
	}
	//set get method for balance
	public void setBalance(double d){
		balance = d;
	}
	public double getBalance(){
		return balance;
	}
	public void showDetails(){
		System.out.println("Account Holder Name is: "+ accountHolderName);
		System.out.println("Account Number is: "+ accountNumber);
		System.out.println("Account Balance is: "+ balance);
		System.out.println("Organization  is: "+ organization);
		
	}
	public static void main(String[] args){
		Account acc1 = new Account();
		acc1.setAccountHolderName("Rifat");
		acc1.setAccountNumber(214536);
		acc1.setBalance(0);
		acc1.showDetails();
	}
}