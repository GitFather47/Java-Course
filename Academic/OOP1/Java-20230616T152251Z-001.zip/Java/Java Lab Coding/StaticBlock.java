import java.util.Scanner;

class StaticBlock {
  public static void main(String[] args) {
    Scanner myObj = new Scanner(System.in);

    System.out.println("Enter name, age and salary:");

    // String input
    char gender = myObj.next().charAt(0);

    // Numerical input
    int age = myObj.nextInt();
    double salary = myObj.nextDouble();

    // Output input by user
    System.out.println("Name: " + gender);
    System.out.println("Age: " + age);
    System.out.println("Salary: " + salary);
  }
}
		
		
