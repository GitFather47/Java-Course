public class Box{
	double length;
	double width;
	double height;
	Box(){
		System.out.println(length);
		System.out.println(width);
		System.out.println(height);
	}
	Box(double length, double width, double height){
		this.length = length;
		this.width=width;
		this.height=height;
//		System.out.println("length:"+ length);
	//	System.out.println("width:"+ width);
		//System.out.println("height:" + height);
	}
	double getLength(){
		return length;
	}
	
	public static void main(String[] args){
		Box b = new Box();
		Box b1 = new Box(1.5,1.2,1.3);
		Box b2 = new Box(2.5,2.2,2.3);
		Box b3 = new Box(3.5,3.2,3.3);
		Box boxes[] = new Box[3];
		
		
	}
}