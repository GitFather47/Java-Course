import java.util.Scanner;
public class ScannerLab{
	public static void main(String[] args){
		Scanner input = new Scanner(System.in);
		System.out.print("Enter an Integer Number: ");
		int n1 = input.nextInt();
		System.out.println("Your Integer Number Is: "+ n1);
		System.out.print("Enter a Float Number: ");
		float n2 = input.nextFloat();
		System.out.println("Your Float Number is: " + n2);
	}
}