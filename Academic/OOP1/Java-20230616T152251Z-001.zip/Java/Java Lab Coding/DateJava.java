import java.util.Date;
import java.awt.*;
public class DateJava{
	public static void main(String[] args){
		Date d = new Date();
		System.out.println(d);
		byte x = 1;
		byte y = x;
		x =3; //primitive type . so it is independent.
		System.out.println(y);
		Point point1 = new Point(1,2);
		Point point2 = point1; //reference type. It's going to store point memory address
		System.out.println("Point 1 Value is: "+point1);
		point1.x = 3;
		System.out.println("Point 2 Value is: "+point2); //dependend 
		
	}
}