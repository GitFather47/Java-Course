public class Dynamic_Method_Dispatch{
	public static void main(String[] args){
	Phone obj = new SmartPhone();
	//It is allowed and this is call dynamic dispatch
	// In this method we can only get access from super class.
	//So which methods are in super class we can only run them or Override them
	SmartPhone obj2 =new SmartPhone();
		obj.name();
		obj.on();
		obj2.music();
	}
}
class Phone{
	public void name(){
		System.out.println("Nokia-1120");
	}
	public void on(){
		System.out.println("Phone is Turning On....");
	}
	
} 
class SmartPhone extends Phone{
	public void name(){
		System.out.println("Walton Primo H6");
	}
	public void music(){
	System.out.println("Playing Music....");	
	}
}
