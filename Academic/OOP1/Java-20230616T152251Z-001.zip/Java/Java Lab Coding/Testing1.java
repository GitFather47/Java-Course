public class Testing1{
	Testing1(){}
	Testing1(String n){
		String name = n;
		System.out.println(name);
	}
	public static void main(String[] args){
		Testing1 t = new Testing1();
		String name1 = name;
		System.out.println(name1);
		
	}
}