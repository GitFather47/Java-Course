import java.util.Random;
import java.util.Scanner;
public class Rock_paper_scisscor{
	public static void main(String[] args){
	/*
	0 for rock
	1 for paper
	2 for scissor
	*/
		int randNumber;
		int numberTaking;
		Random rand = new Random();
		randNumber = rand.nextInt(3);
		//System.out.println(randNumber);
		Scanner input = new Scanner(System.in);
		System.out.println("Input a number between 0 to 2");
		numberTaking = input.nextInt();
		if(randNumber==0 && numberTaking==0){
			System.out.println("Draw");
		}
		else if (randNumber==0 && numberTaking==1){
			System.out.println("You Win!!");
		}
		else if(randNumber == 1 && numberTaking==1){
			System.out.println("Draw");
	}
	  else if(randNumber == 2 && numberTaking==1){
		  System.out.println("You loose!!");
	  }
	}
}