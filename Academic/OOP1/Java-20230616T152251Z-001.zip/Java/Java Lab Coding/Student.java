public class Student{
	private int id;
	private String name;
	private double cgpa;
	public void setId(int i){
		id = i;
	}
	public int getId(){
		return id;
	}
	public void setName(String n){
		name = n;
	}
	public String getName(){
		return name;
	}
	public void setCgpa(double cg){
		cgpa = cg;
	}
	public double getCgpa(){
		return cgpa;
	}
	public void showDetails(){
		System.out.println("Student Name is: "+name);
		System.out.println("Student ID is: "+id);
		System.out.println("Student cgpa is: "+cgpa);
	}
}