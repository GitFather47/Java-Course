public class OutputTracing{
	String name;
	public static String organization;
	static{
		organization = "Aiub";
		System.out.println(organization);
	}
	public static void main(String[] args){
		System.out.println("Hello");
		
	}
} 