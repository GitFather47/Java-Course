package interfaces;
import classes.*;
 interface StudentsOperations{
	void insertStudent(Student s);
	void removeStudent(Student s);
	Student getStudent(String name);
	void ShowAllStudents();
}