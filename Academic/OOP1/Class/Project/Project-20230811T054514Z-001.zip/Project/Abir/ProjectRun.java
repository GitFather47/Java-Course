import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.event.ActionEvent.*;
import java.text.*;
import java.util.*;
 
public class ProjectRun
{
	
	public static void main(String[] args)
	{  
	LogIn l = new LogIn();
	 /*IDP idp = new IDP();
	 LogIn lp = new LogIn(idp.getLI());*/
	} 
}