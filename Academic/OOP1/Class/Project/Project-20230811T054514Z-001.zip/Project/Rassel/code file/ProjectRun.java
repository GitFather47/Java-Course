import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.event.ActionEvent.*;
import java.text.*;
import java.util.*;
 
public class ProjectRun{
	
	public static void main(String[] args)
	{  
		//new Teacher();
		//new UploadNotes();
		new LogIn();
		//new PopupUpload();
		//new ViewProfile();
		//new UpdateProfile ();
		//new StudentList ();
		//new Form();
		//new Teachers();
		//new Admin();
		//new LogOut();
	} 
}