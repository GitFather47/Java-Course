import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.event.ActionEvent.*;
import java.text.*;
import java.util.*;
 
public class ProjectRun{
	
	public static void main(String[] args)
	{  
		//new Teacher("5");
		//new UploadNotes("5");
		new LogIn();
		//new ViewProfile("5");
		//new UpdateProfile ("5");
		//new StudentList ("5");
		//new UploadGrade ("5");
		//new LogOut();
		//ViewProfile1 v = new ViewProfile1("5");
		//v.setVisible(true);
		//new Update();
		//new Schedule2();
		//new Schedule1("5");
		//new Schedule("5");
		//new ForgotPass ();
		//new Student ("5");
		//new Notice("5");
		//new Payment("5");
		////Result r = new Result("5");
		//r.setVisible(true);
		//new Admin();
		//new Notice1();
		//new Teachers();
		//new Students();
		//new Profile();
		//new SPay();
	} 
}