import java.lang.*;

public class StartL
{
	public static void main(String args[])
	{
		
		Student s = new Student();
		s.setVisible(true);
		
		//Payment s = new Payment();
		//s.setVisible(true);
		
	    // LogIn l = new LogIn();
		// l.setVisible(true);
		//Result r = new Result();
		//r.setVisible(true);
		//ViewProfile v = new ViewProfile();
		//v.setVisible(true);
	}
}