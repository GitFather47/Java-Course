package FlyUSA;
import FlyUSA.mainFrame.AppFrame;
class Start{
    public static void main(String[] args) {
        AppFrame a1 = new AppFrame();
        
    }
}