package FlyUSA.controller;
public interface IFeature {
	public void passengerInfo();
	public void show();
	public void install();
	public void avail();
}